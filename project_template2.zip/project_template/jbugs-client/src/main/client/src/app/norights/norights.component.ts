import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-norights',
  templateUrl: './norights.component.html',
  styleUrls: ['./norights.component.css']
})
export class NorightsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
