export class Permission {
  type: string;
  description: string;
}
